import React, { useState, useEffect } from 'react';
import {
    View,
    Text,
    TextInput,
    TouchableOpacity,
    StyleSheet,
    KeyboardAvoidingView,
    Platform,
    ScrollView,
    ActivityIndicator,
    Switch
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ArrowLeft, Save, Calendar as CalendarIcon, Flag, Bell } from 'lucide-react-native';
import DateTimePicker from '@react-native-community/datetimepicker';
import api from '../api/axiosConfig';
import SweetAlert from '../components/SweetAlert';

export default function TaskDetailScreen({ route, navigation }) {
    const { task } = route.params || {};
    const isEditing = !!task;

    const [title, setTitle] = useState(task?.title || '');
    const [description, setDescription] = useState(task?.description || '');
    const [dueDate, setDueDate] = useState(task?.dueDate ? task.dueDate.split('T')[0] : '');
    const [dueTime, setDueTime] = useState(task?.dueDate ? task.dueDate.split('T')[1]?.substring(0, 5) : '10:00');
    const [priority, setPriority] = useState(task?.priority || 'Medium');
    const [loading, setLoading] = useState(false);
    const [showDatePicker, setShowDatePicker] = useState(false);
    const [showTimePicker, setShowTimePicker] = useState(false);
    const [reminder, setReminder] = useState(task?.reminder || false);

    // Alert State
    const [alertConfig, setAlertConfig] = useState({
        visible: false,
        type: 'success',
        title: '',
        message: '',
        onConfirm: () => { }
    });

    const onDateChange = (event, selectedDate) => {
        setShowDatePicker(false);
        if (selectedDate) {
            const year = selectedDate.getFullYear();
            const month = String(selectedDate.getMonth() + 1).padStart(2, '0');
            const day = String(selectedDate.getDate()).padStart(2, '0');
            setDueDate(`${year}-${month}-${day}`);
        }
    };

    const onTimeChange = (event, selectedDate) => {
        setShowTimePicker(false);
        if (selectedDate) {
            const hours = String(selectedDate.getHours()).padStart(2, '0');
            const minutes = String(selectedDate.getMinutes()).padStart(2, '0');
            setDueTime(`${hours}:${minutes}`);
        }
    };

    const showAlert = (type, title, message, onConfirm) => {
        setAlertConfig({
            visible: true,
            type,
            title,
            message,
            onConfirm: () => {
                setAlertConfig(prev => ({ ...prev, visible: false }));
                if (onConfirm) onConfirm();
            }
        });
    };

    const handleSave = async () => {
        if (!title) {
            showAlert('warning', 'Missing Title', 'Please enter a title for your task.');
            return;
        }

        if (dueDate && !/^\d{4}-\d{2}-\d{2}$/.test(dueDate)) {
            showAlert('error', 'Invalid Date', 'The date format is incorrect.');
            return;
        }

        setLoading(true);
        try {
            let combinedDateTime = null;
            if (dueDate) {
                combinedDateTime = `${dueDate}T${dueTime || '00:00'}:00`;
            }

            const payload = {
                title,
                description,
                dueDate: combinedDateTime,
                priority,
                status: task?.status || 'Pending',
                reminder,
                reminderTime: reminder ? combinedDateTime : null
            };

            if (isEditing) {
                await api.put(`/tasks/${task.id}`, payload);
            } else {
                await api.post('/tasks', payload);
            }

            showAlert('success', 'Task Saved!', 'Your task has been successfully saved.', () => {
                navigation.goBack();
            });
        } catch (error) {
            if (error.response?.status === 401) {
                showAlert('info', 'Session Expired', 'Please login again to continue.', async () => {
                    await AsyncStorage.removeItem('userToken');
                    await AsyncStorage.removeItem('userId');
                    navigation.replace('Login');
                });
            } else {
                const msg = error.response?.data?.message || error.message || "Failed to save the task. Please try again.";
                showAlert('error', 'Update Failed', msg);
            }
        } finally {
            setLoading(false);
        }
    };

    const getPriorityColor = (value) => {
        switch (value) {
            case 'High': return '#ef4444';
            case 'Medium': return '#f59e0b';
            case 'Low': return '#10b981';
            default: return '#6b7280';
        }
    };

    return (
        <SafeAreaView style={styles.container}>
            <KeyboardAvoidingView
                behavior={Platform.OS === 'ios' ? 'padding' : undefined}
                style={styles.container}
            >
                <View style={styles.header}>
                    <TouchableOpacity
                        style={styles.backBtn}
                        onPress={() => navigation.goBack()}
                    >
                        <ArrowLeft color="#ffffff" size={24} />
                    </TouchableOpacity>
                    <Text style={styles.headerTitle}>
                        {isEditing ? 'Edit Task' : 'New Task'}
                    </Text>
                    <View style={{ width: 44 }} />
                </View>

                <ScrollView
                    style={styles.content}
                    showsVerticalScrollIndicator={false}
                >
                    <View style={styles.section}>
                        <Text style={styles.label}>Task Title</Text>
                        <TextInput
                            style={styles.input}
                            placeholder="e.g. Design UI Mockups"
                            placeholderTextColor="#8e8e93"
                            value={title}
                            onChangeText={setTitle}
                        />
                    </View>

                    <View style={styles.section}>
                        <Text style={styles.label}>Description (Optional)</Text>
                        <TextInput
                            style={[styles.input, styles.textArea]}
                            placeholder="Add details about your task"
                            placeholderTextColor="#8e8e93"
                            multiline={true}
                            numberOfLines={4}
                            textAlignVertical="top"
                            value={description}
                            onChangeText={setDescription}
                        />
                    </View>

                    <View style={styles.section}>
                        <View style={{ flexDirection: 'row', gap: 12 }}>
                            <View style={{ flex: 1 }}>
                                <Text style={styles.label}>Due Date</Text>
                                <TouchableOpacity
                                    style={styles.inputContainer}
                                    onPress={() => setShowDatePicker(true)}
                                >
                                    <CalendarIcon color="#8e8e93" size={20} style={styles.icon} />
                                    <Text style={[styles.inputWrapper, !dueDate && { color: '#8e8e93' }]}>
                                        {dueDate || 'YYYY-MM-DD'}
                                    </Text>
                                </TouchableOpacity>
                            </View>
                            <View style={{ flex: 1 }}>
                                <Text style={styles.label}>Time</Text>
                                <TouchableOpacity
                                    style={styles.inputContainer}
                                    onPress={() => setShowTimePicker(true)}
                                >
                                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                        <Text style={styles.inputWrapper}>{dueTime}</Text>
                                    </View>
                                </TouchableOpacity>
                            </View>
                        </View>

                        {showDatePicker && (
                            <DateTimePicker
                                value={dueDate ? new Date(dueDate) : new Date()}
                                mode="date"
                                display="default"
                                onChange={onDateChange}
                            />
                        )}

                        {showTimePicker && (
                            <DateTimePicker
                                value={new Date(`2000-01-01T${dueTime}:00`)}
                                mode="time"
                                is24Hour={true}
                                display="default"
                                onChange={onTimeChange}
                            />
                        )}
                    </View>

                    <View style={styles.section}>
                        <Text style={styles.label}>Priority</Text>
                        <View style={styles.priorityContainer}>
                            {['High', 'Medium', 'Low'].map((p) => (
                                <TouchableOpacity
                                    key={p}
                                    style={[
                                        styles.priorityBtn,
                                        priority === p && {
                                            backgroundColor: getPriorityColor(p) + '20',
                                            borderColor: getPriorityColor(p)
                                        }
                                    ]}
                                    onPress={() => setPriority(p)}
                                >
                                    <Flag
                                        color={priority === p ? getPriorityColor(p) : '#a1a1aa'}
                                        size={16}
                                        style={styles.priorityIcon}
                                    />
                                    <Text
                                        style={[
                                            styles.priorityText,
                                            priority === p && { color: getPriorityColor(p) }
                                        ]}
                                    >
                                        {p}
                                    </Text>
                                </TouchableOpacity>
                            ))}
                        </View>
                    </View>

                    <View style={styles.section}>
                        <View style={styles.reminderContainer}>
                            <View style={styles.reminderInfo}>
                                <Bell color="#6366f1" size={20} style={{ marginRight: 12 }} />
                                <View>
                                    <Text style={styles.reminderTitle}>Set Reminder</Text>
                                    <Text style={styles.reminderSubtitle}>Get an in-app alert when due</Text>
                                </View>
                            </View>
                            <Switch
                                trackColor={{ false: '#27272a', true: '#6366f1' }}
                                thumbColor="#ffffff"
                                ios_backgroundColor="#27272a"
                                onValueChange={setReminder}
                                value={reminder}
                            />
                        </View>
                    </View>
                </ScrollView>

                <View style={styles.footer}>
                    <TouchableOpacity
                        style={styles.saveBtn}
                        onPress={handleSave}
                        disabled={loading}
                    >
                        {loading ? (
                            <ActivityIndicator color="#ffffff" />
                        ) : (
                            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                                <Save color="#ffffff" size={20} />
                                <Text style={styles.saveBtnText}>Save Task</Text>
                            </View>
                        )}
                    </TouchableOpacity>
                </View>
            </KeyboardAvoidingView>

            <SweetAlert
                visible={alertConfig.visible}
                type={alertConfig.type}
                title={alertConfig.title}
                message={alertConfig.message}
                onConfirm={alertConfig.onConfirm}
            />
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#0a0a0c',
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: 16,
        paddingVertical: 16,
        borderBottomWidth: 1,
        borderBottomColor: '#18181b',
    },
    backBtn: {
        width: 44,
        height: 44,
        justifyContent: 'center',
        alignItems: 'center',
    },
    headerTitle: {
        fontSize: 18,
        fontWeight: '700',
        color: '#ffffff',
    },
    content: {
        flex: 1,
        padding: 24,
    },
    section: {
        marginBottom: 24,
    },
    label: {
        fontSize: 14,
        fontWeight: '600',
        color: '#a1a1aa',
        marginBottom: 8,
        marginLeft: 4,
    },
    input: {
        backgroundColor: '#18181b',
        borderRadius: 16,
        paddingHorizontal: 16,
        height: 56,
        color: '#ffffff',
        fontSize: 16,
        borderWidth: 1,
        borderColor: '#27272a',
    },
    textArea: {
        height: 120,
        paddingTop: 16,
        paddingBottom: 16,
    },
    inputContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#18181b',
        borderRadius: 16,
        paddingHorizontal: 16,
        height: 56,
        borderWidth: 1,
        borderColor: '#27272a',
    },
    icon: {
        marginRight: 12,
    },
    inputWrapper: {
        flex: 1,
        color: '#ffffff',
        fontSize: 16,
    },
    priorityContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        gap: 12,
    },
    priorityBtn: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        height: 48,
        borderRadius: 12,
        backgroundColor: '#18181b',
        borderWidth: 1,
        borderColor: '#27272a',
    },
    priorityIcon: {
        marginRight: 6,
    },
    priorityText: {
        color: '#a1a1aa',
        fontSize: 14,
        fontWeight: '600',
    },
    footer: {
        padding: 24,
        borderTopWidth: 1,
        borderTopColor: '#18181b',
        backgroundColor: '#0a0a0c',
    },
    saveBtn: {
        backgroundColor: '#6366f1',
        borderRadius: 16,
        height: 56,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        shadowColor: '#6366f1',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.3,
        shadowRadius: 8,
        elevation: 5,
        gap: 8,
    },
    saveBtnText: {
        color: '#ffffff',
        fontSize: 16,
        fontWeight: '700',
        letterSpacing: 0.5,
    },
    reminderContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        backgroundColor: '#18181b',
        borderRadius: 16,
        padding: 16,
        borderWidth: 1,
        borderColor: '#27272a',
    },
    reminderInfo: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    reminderTitle: {
        color: '#ffffff',
        fontSize: 16,
        fontWeight: '600',
    },
    reminderSubtitle: {
        color: '#a1a1aa',
        fontSize: 12,
        marginTop: 2,
    },
});
