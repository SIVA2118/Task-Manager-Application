$env:JAVA_HOME = 'C:\Program Files\Java\jdk-17'
.\mvnw spring-boot:run | Out-File -FilePath run_output.txt -Encoding utf8
